import React from 'react';
import ReactDOM from 'react-dom/client';
import { Shield, Terminal, Code2, Network, Database, Instagram, ArrowDown, Award, Globe2 } from 'lucide-react';
import './styles.css';

const skills = [
  { name: 'Cybersecurity', icon: Shield },
  { name: 'Ethical Hacking', icon: Terminal },
  { name: 'HTML / CSS', icon: Code2 },
  { name: 'Java', icon: Code2 },
  { name: 'C#', icon: Code2 },
  { name: 'Networking', icon: Network },
  { name: 'SQL Injection Basics', icon: Database },
  { name: 'Vulnerability Testing', icon: Shield },
];

const achievements = [
  'Cisco completed',
  'Web Development completed',
  'Foundation in Cybersecurity completed',
  'Currently studying cybersecurity at ILS Institute, Srinagar'
];

function Navbar() {
  return (
    <nav className="nav glass">
      <div className="brand">SHANIB<span>.</span></div>
      <div className="links">
        <a href="#about">About</a>
        <a href="#skills">Skills</a>
        <a href="#work">Work</a>
        <a href="#contact">Contact</a>
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <section className="hero">
      <video className="bg-video" autoPlay loop muted playsInline>
        <source src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260314_131748_f2ca2a28-fed7-44c" />
      </video>
      <div className="overlay"></div>
      <div className="orb orb-one"></div>
      <div className="orb orb-two"></div>
      <Navbar />
      <div className="hero-content">
        <p className="eyebrow">Cybersecurity Student • Ethical Hacking • Web Development</p>
        <h1>Sheikh Shanib</h1>
        <p className="tagline">Building my empire one step at a time.</p>
        <div className="hero-actions">
          <a className="btn primary" href="#work">View Portfolio</a>
          <a className="btn ghost" href="https://www.instagram.com/vib3swith_shanib_/" target="_blank">Instagram</a>
        </div>
      </div>
      <a className="scroll" href="#about"><ArrowDown size={22}/></a>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="section split">
      <div>
        <p className="section-label">About Me</p>
        <h2>A future cybersecurity professional from Charar-i-Sharief.</h2>
      </div>
      <div className="glass card">
        <p>
          I am Sheikh Shanib, a cybersecurity student focused on ethical hacking,
          networking, secure web development, and vulnerability assessment.
          My goal is to build strong technical skills and create premium digital work
          that looks modern, cinematic, and professional.
        </p>
      </div>
    </section>
  );
}

function Skills() {
  return (
    <section id="skills" className="section">
      <p className="section-label">Skills</p>
      <h2>Technical Arsenal</h2>
      <div className="skill-grid">
        {skills.map(({ name, icon: Icon }) => (
          <div className="skill glass" key={name}>
            <Icon size={28}/>
            <span>{name}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function Work() {
  return (
    <section id="work" className="section">
      <p className="section-label">Portfolio</p>
      <h2>Projects & Learning Journey</h2>
      <div className="project-grid">
        <article className="project glass">
          <Globe2 />
          <h3>Premium Portfolio Website</h3>
          <p>Cinematic hero, animated sections, glassmorphism design, and cybersecurity branding.</p>
        </article>
        <article className="project glass">
          <Shield />
          <h3>Security Practice Labs</h3>
          <p>Learning web vulnerabilities including XSS, CSRF, SQL injection basics, and secure testing methods.</p>
        </article>
        <article className="project glass">
          <Award />
          <h3>Certifications & Training</h3>
          <ul>
            {achievements.map(item => <li key={item}>{item}</li>)}
          </ul>
        </article>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="section contact">
      <div className="glass contact-box">
        <p className="section-label">Contact</p>
        <h2>Let’s build something powerful.</h2>
        <p>Follow my journey and connect with me on Instagram.</p>
        <a className="btn primary" href="https://www.instagram.com/vib3swith_shanib_/" target="_blank">
          <Instagram size={18}/> Open Instagram
        </a>
      </div>
    </section>
  );
}

function App() {
  return (
    <>
      <Hero />
      <About />
      <Skills />
      <Work />
      <Contact />
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
