# Sheikh Shanib Cinematic Portfolio

## How to run on your phone/laptop
1. Upload this ZIP to GitHub.
2. Open the project in StackBlitz, CodeSandbox, Replit, or VS Code.
3. Run:

```bash
npm install
npm run dev
```

## How to upload on Google / publish online
Best free method:
1. Create a GitHub repository.
2. Upload all files from this ZIP.
3. Go to Vercel.com.
4. Sign in with GitHub.
5. Import your repository.
6. Click Deploy.
7. Vercel gives you a live website URL.

## To add your own photo
Put your image inside `public/` and then edit `src/main.tsx` to show it in the About or Hero section.
